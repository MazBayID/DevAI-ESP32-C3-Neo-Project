#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

static const char *TAG = "NEO";

/*
 * Neo Pocket AI v0.2
 *
 * OLED:      SDA GPIO21, SCL GPIO20
 * INMP441:   SCK GPIO2, WS GPIO1, SD GPIO8
 * MAX98357:  DIN GPIO3, BCLK GPIO2, LRC GPIO1
 * Switch:    not used
 *
 * v0.2 is a boot/runtime test. Audio and OLED drivers come later.
 */

void app_main(void)
{
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, " Neo Pocket AI v0.2");
    ESP_LOGI(TAG, " Native ESP-IDF firmware");
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "OLED  SDA  = GPIO21");
    ESP_LOGI(TAG, "OLED  SCL  = GPIO20");
    ESP_LOGI(TAG, "MIC   SCK  = GPIO2");
    ESP_LOGI(TAG, "MIC   WS   = GPIO1");
    ESP_LOGI(TAG, "MIC   SD   = GPIO8");
    ESP_LOGI(TAG, "AMP   DIN  = GPIO3");
    ESP_LOGI(TAG, "AMP   BCLK = GPIO2");
    ESP_LOGI(TAG, "AMP   LRC  = GPIO1");
    ESP_LOGI(TAG, "SWITCH     = not used");
    ESP_LOGI(TAG, "Firmware booted successfully.");

    uint32_t seconds = 0;
    while (1) {
        ESP_LOGI(TAG, "Neo alive: %lu s", (unsigned long)seconds++);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
