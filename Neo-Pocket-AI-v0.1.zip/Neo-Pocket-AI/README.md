# Neo Pocket AI

Custom ESP32-C3 Pocket AI firmware project.

## Hardware mapping

OLED:
- SDA GPIO21
- SCL GPIO20

INMP441:
- SCK GPIO2
- WS GPIO1
- SD GPIO8

MAX98357:
- DIN GPIO3
- BCLK GPIO2
- LRC GPIO1

Switch:
- Not used.

## Build

GitHub Actions automatically compiles the firmware when code is pushed to `main`/`master`, or it can be started manually from the Actions tab.

The resulting `.bin` is published as a GitHub Actions artifact.

## Development roadmap

1. OLED + boot test
2. I2S microphone test
3. I2S speaker test
4. Wi-Fi
5. Neo backend
6. OpenAI integration
7. Voice conversation
8. Optional web control UI

API keys are intentionally NOT included in firmware.
