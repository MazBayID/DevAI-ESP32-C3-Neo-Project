#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ============================================================
// Neo Pocket AI - Hardware Foundation
// ESP32-C3
// Mapping follows the user's Huy Vector-style wiring.
// ============================================================

// OLED
#define OLED_SDA 21
#define OLED_SCL 20
#define OLED_ADDR 0x3C
#define OLED_WIDTH 128
#define OLED_HEIGHT 64

// INMP441
#define MIC_SCK  2
#define MIC_WS   1
#define MIC_SD   8

// MAX98357
#define AMP_DIN  3
#define AMP_BCLK 2
#define AMP_LRC  1

Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);

void showBootScreen() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(2);
  display.setCursor(0, 0);
  display.println("NEO");

  display.setTextSize(1);
  display.println();
  display.println("Pocket AI");
  display.println("Hardware test");
  display.println();
  display.println("OLED: OK");
  display.display();
}

void setup() {
  Serial.begin(115200);
  delay(500);

  Wire.begin(OLED_SDA, OLED_SCL);

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("OLED ERROR");
    while (true) {
      delay(1000);
    }
  }

  Serial.println();
  Serial.println("================================");
  Serial.println(" Neo Pocket AI");
  Serial.println(" Hardware Foundation");
  Serial.println("================================");
  Serial.println("OLED SDA : GPIO21");
  Serial.println("OLED SCL : GPIO20");
  Serial.println("MIC SCK  : GPIO2");
  Serial.println("MIC WS   : GPIO1");
  Serial.println("MIC SD   : GPIO8");
  Serial.println("AMP DIN  : GPIO3");
  Serial.println("AMP BCLK : GPIO2");
  Serial.println("AMP LRC  : GPIO1");
  Serial.println("Switch   : not used");
  Serial.println("================================");

  showBootScreen();
}

void loop() {
  static unsigned long last = 0;
  static uint32_t seconds = 0;

  if (millis() - last >= 1000) {
    last = millis();
    seconds++;

    Serial.print("Neo alive - ");
    Serial.print(seconds);
    Serial.println(" s");

    display.clearDisplay();

    // Simple eyes / idle face
    display.fillRoundRect(18, 18, 32, 24, 8, SSD1306_WHITE);
    display.fillRoundRect(78, 18, 32, 24, 8, SSD1306_WHITE);

    display.fillCircle(34, 30, 6, SSD1306_BLACK);
    display.fillCircle(94, 30, 6, SSD1306_BLACK);

    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(46, 53);
    display.print("Neo ");

    if (seconds % 2 == 0) {
      display.print("OK");
    } else {
      display.print("...");
    }

    display.display();
  }
}
