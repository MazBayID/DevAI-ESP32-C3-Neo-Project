#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <inttypes.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_system.h"
#include "esp_chip_info.h"
#include "esp_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"

#include "driver/i2c_master.h"
#include "driver/i2s_std.h"

#define TAG "NEO_DIAG"

/* Current physical wiring */
#define OLED_SDA 21
#define OLED_SCL 20
#define OLED_ADDR 0x3C

#define I2S_BCLK 2
#define I2S_WS   1
#define MIC_SD   8
#define SPK_DOUT 3

static void print_banner(void)
{
    esp_chip_info_t chip;
    esp_chip_info(&chip);

    uint32_t flash_size = 0;
    esp_flash_get_size(NULL, &flash_size);

    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, " Neo Diagnostic v1.0");
    ESP_LOGI(TAG, " ESP-IDF: %s", esp_get_idf_version());
    ESP_LOGI(TAG, " Chip cores: %d", chip.cores);
    ESP_LOGI(TAG, " Flash: %" PRIu32 " bytes", flash_size);
    ESP_LOGI(TAG, " OLED: SDA=%d SCL=%d ADDR=0x%02X",
             OLED_SDA, OLED_SCL, OLED_ADDR);
    ESP_LOGI(TAG, " I2S: BCLK=%d WS=%d MIC_SD=%d SPK_DOUT=%d",
             I2S_BCLK, I2S_WS, MIC_SD, SPK_DOUT);
    ESP_LOGI(TAG, " Bluetooth: DISABLED");
    ESP_LOGI(TAG, " WiFi TX target: 10 dBm");
    ESP_LOGI(TAG, "========================================");
}

static void oled_test(void)
{
    ESP_LOGI(TAG, "[OLED] Testing I2C...");

    i2c_master_bus_config_t bus_cfg = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = OLED_SDA,
        .scl_io_num = OLED_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };

    i2c_master_bus_handle_t bus = NULL;
    esp_err_t err = i2c_new_master_bus(&bus_cfg, &bus);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "[OLED] I2C bus init FAILED: %s", esp_err_to_name(err));
        return;
    }

    err = i2c_master_probe(bus, OLED_ADDR, 100);

    if (err == ESP_OK) {
        ESP_LOGI(TAG, "[OLED] Device found at 0x%02X", OLED_ADDR);
    } else {
        ESP_LOGW(TAG, "[OLED] Device NOT found at 0x%02X: %s",
                 OLED_ADDR, esp_err_to_name(err));
    }

    i2c_del_master_bus(bus);
}

static void i2s_test(void)
{
    ESP_LOGI(TAG, "[I2S] Testing shared-clock full duplex...");
    ESP_LOGI(TAG, "[I2S] BCLK=%d WS=%d MIC_SD=%d SPK_DOUT=%d",
             I2S_BCLK, I2S_WS, MIC_SD, SPK_DOUT);

    i2s_chan_handle_t tx = NULL;
    i2s_chan_handle_t rx = NULL;

    i2s_chan_config_t chan_cfg =
        I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);

    esp_err_t err = i2s_new_channel(&chan_cfg, &tx, &rx);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "[I2S] Channel creation FAILED: %s",
                 esp_err_to_name(err));
        return;
    }

    i2s_std_config_t cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(16000),
        .slot_cfg = I2S_STD_MSB_SLOT_DEFAULT_CONFIG(
            I2S_DATA_BIT_WIDTH_32BIT,
            I2S_SLOT_MODE_MONO
        ),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = I2S_BCLK,
            .ws = I2S_WS,
            .dout = SPK_DOUT,
            .din = MIC_SD,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    if (rx) {
        err = i2s_channel_init_std_mode(rx, &cfg);
        if (err == ESP_OK) {
            err = i2s_channel_enable(rx);
        }

        if (err == ESP_OK) {
            uint8_t buf[256] = {0};
            size_t bytes_read = 0;
            esp_err_t read_err = i2s_channel_read(
                rx, buf, sizeof(buf), &bytes_read, 200
            );

            if (read_err == ESP_OK || bytes_read > 0) {
                ESP_LOGI(TAG, "[MIC] Read OK: %u bytes", (unsigned)bytes_read);
            } else {
                ESP_LOGW(TAG, "[MIC] Read returned: %s",
                         esp_err_to_name(read_err));
            }

            i2s_channel_disable(rx);
        } else {
            ESP_LOGE(TAG, "[MIC] Init/enable FAILED: %s",
                     esp_err_to_name(err));
        }
    }

    if (tx) {
        err = i2s_channel_init_std_mode(tx, &cfg);
        if (err == ESP_OK) {
            err = i2s_channel_enable(tx);
        }

        if (err == ESP_OK) {
            uint8_t silence[256] = {0};
            size_t bytes_written = 0;
            esp_err_t write_err = i2s_channel_write(
                tx, silence, sizeof(silence), &bytes_written, 200
            );

            if (write_err == ESP_OK) {
                ESP_LOGI(TAG, "[SPK] Digital TX write OK: %u bytes",
                         (unsigned)bytes_written);
            } else {
                ESP_LOGW(TAG, "[SPK] TX write returned: %s",
                         esp_err_to_name(write_err));
            }

            i2s_channel_disable(tx);
        } else {
            ESP_LOGE(TAG, "[SPK] Init/enable FAILED: %s",
                     esp_err_to_name(err));
        }
    }

    i2s_del_channel(tx);
    i2s_del_channel(rx);
}

static void wifi_test(void)
{
    ESP_LOGI(TAG, "[WIFI] Starting radio scan test...");

    esp_netif_init();
    esp_event_loop_create_default();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_err_t err = esp_wifi_init(&cfg);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "[WIFI] Init FAILED: %s", esp_err_to_name(err));
        return;
    }

    esp_wifi_set_mode(WIFI_MODE_STA);
    esp_wifi_set_max_tx_power(40); /* 40 quarter-dBm units = 10 dBm */
    esp_wifi_start();

    wifi_scan_config_t scan_cfg = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,
        .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
        .scan_time.active.min = 100,
        .scan_time.active.max = 300,
    };

    err = esp_wifi_scan_start(&scan_cfg, true);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "[WIFI] Scan FAILED: %s", esp_err_to_name(err));
        esp_wifi_stop();
        esp_wifi_deinit();
        return;
    }

    uint16_t count = 0;
    esp_wifi_scan_get_ap_num(&count);
    ESP_LOGI(TAG, "[WIFI] Networks found: %u", count);

    uint16_t shown = count > 10 ? 10 : count;
    wifi_ap_record_t *records = NULL;

    if (shown > 0) {
        records = calloc(shown, sizeof(wifi_ap_record_t));
        if (records) {
            uint16_t num = shown;
            if (esp_wifi_scan_get_ap_records(&num, records) == ESP_OK) {
                for (uint16_t i = 0; i < num; i++) {
                    ESP_LOGI(TAG, "[WIFI] %u: %s RSSI=%d CH=%d",
                             i + 1,
                             (char *)records[i].ssid,
                             records[i].rssi,
                             records[i].primary);
                }
            }
            free(records);
        }
    }

    esp_wifi_stop();
    esp_wifi_deinit();

    ESP_LOGI(TAG, "[WIFI] Scan test complete.");
}

void app_main(void)
{
    print_banner();

    vTaskDelay(pdMS_TO_TICKS(500));

    oled_test();
    vTaskDelay(pdMS_TO_TICKS(300));

    i2s_test();
    vTaskDelay(pdMS_TO_TICKS(300));

    wifi_test();

    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, " DIAGNOSTIC COMPLETE");
    ESP_LOGI(TAG, "========================================");

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}
