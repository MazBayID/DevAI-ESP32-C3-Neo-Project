# Neo Pocket AI v0.2

Native ESP-IDF 5.5.2 foundation for ESP32-C3.

## Pin mapping
OLED: SDA GPIO21, SCL GPIO20
INMP441: SCK GPIO2, WS GPIO1, SD GPIO8
MAX98357: DIN GPIO3, BCLK GPIO2, LRC GPIO1
Switch: not used

## Build
GitHub Actions installs ESP-IDF 5.5.2, builds ESP32-C3, merges the flash images with `idf.py merge-bin`, and uploads `release/neo_pocket_ai-merged.bin`.

The merged image is intended for flash address `0x00000000`.

## v0.2 scope
ESP32-C3 boot/runtime and serial logging only. OLED/I2S drivers come in later versions.

## Roadmap
v0.3 OLED
v0.4 INMP441
v0.5 MAX98357
v0.6 Wi-Fi
v0.7 HTTPS/backend
v0.8 OpenAI
v0.9 voice conversation
v1.0 Pocket AI
