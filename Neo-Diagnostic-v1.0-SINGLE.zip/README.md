# Neo Diagnostic v1.0

ESP32-C3 hardware diagnostic firmware for:
- OLED I2C: SDA 21, SCL 20, address 0x3C
- Shared I2S clocks: BCLK 2, WS 1
- INMP441 SD: GPIO 8
- MAX98357A DIN: GPIO 3
- Bluetooth disabled
- Wi-Fi TX power limited to 10 dBm
- Wi-Fi scan test

Built for ESP-IDF 5.5.2.
