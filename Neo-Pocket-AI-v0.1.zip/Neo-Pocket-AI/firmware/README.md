# Neo Pocket AI - Firmware

This is the hardware-foundation firmware for the custom ESP32-C3 Pocket AI.

## Pin mapping

### OLED
- SDA = GPIO21
- SCL = GPIO20

### INMP441
- SCK = GPIO2
- WS = GPIO1
- SD = GPIO8

### MAX98357
- DIN = GPIO3
- BCLK = GPIO2
- LRC = GPIO1

### Switch
- Not used.

## Current firmware stage

This first build only verifies:
- ESP32-C3 boot
- OLED initialization
- OLED display
- serial output

Microphone and speaker I2S are intentionally not initialized yet. The shared GPIO1/GPIO2 clock lines need to be tested carefully before the audio layer is added.

## Security

Do NOT put an OpenAI API key into this firmware.

The planned architecture is:

ESP32-C3 -> Neo backend -> OpenAI API

The API key should remain on the backend/server side.
